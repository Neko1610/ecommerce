import 'dart:convert';
import 'package:ecommerce_app/services/cart_service.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/utils/currency_formatter.dart';
import '../core/utils/snackbar_helper.dart';
import '../models/payment_method_model.dart';
import '../providers/PaymentProvider.dart';
import '../widgets/checkout/address_section.dart';
import '../widgets/checkout/shipping_method_section.dart';
import '../widgets/checkout/payment_method_section.dart';
import '../widgets/checkout/order_summary_section.dart';
import '../widgets/checkout/checkout_bottom_bar.dart';
import '../services/order_service.dart';
import '../services/api_client.dart';
import '../models/cart_item.dart';
import '../services/momo_service.dart';
import 'payment_webview.dart';

class CheckoutScreen extends StatefulWidget {
  final List<CartItem> cart;
  final double totalPrice;
  final String voucherCode;

  const CheckoutScreen({
    super.key,
    required this.cart,
    required this.totalPrice,
    required this.voucherCode,
  });

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  double shippingFee = 0;
  double baseShipping = 0;

  int? selectedAddressId;
  String paymentMethod = "COD";

  final orderService = OrderService();

  double get productTotalVND => toVND(widget.totalPrice);
  double get total => productTotalVND + shippingFee;

  Future<String> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString("token") ?? "";
  }

  Future<void> calculateShipping(int addressId) async {
    if (selectedAddressId == addressId) return;

    final token = await getToken();
    final headers = <String, String>{};
    if (token.isNotEmpty) {
      headers["Authorization"] = "Bearer $token";
    }

    final res = await http.post(
      ApiClient.uri("/shipping/calculate/$addressId"),
      headers: headers,
    );

    if (res.body.isEmpty) return;

    final data = jsonDecode(res.body);

    if (!mounted) return;

    final fee = data['fee'];
    double vnd = fee is num ? fee.toDouble() : 0;

    /// 🔥 delay để tránh setState during build
    Future.delayed(Duration.zero, () {
      if (!mounted) return;

      setState(() {
        selectedAddressId = addressId;
        baseShipping = vnd;
        shippingFee = baseShipping;
      });
    });
  }

  List<Map<String, dynamic>> mapCart() {
    return widget.cart.map((e) {
      return {"variantId": e.variantId, "quantity": e.quantity};
    }).toList();
  }

  String effectivePaymentMethod() {
    final selected = context.read<PaymentProvider>().selectedMethod;

    if (selected == null) {
      return paymentMethod;
    }

    switch (selected.type) {
      case PaymentType.momo:
      case PaymentType.zaloPay:
        return "WALLET";
      case PaymentType.creditCard:
        return "CARD";
      case PaymentType.bank:
        return "BANK";
    }
  }

  void handleCheckout() async {
    if (selectedAddressId == null) {
      showAppSnackBar(
        context,
        const SnackBar(content: Text("Vui lòng chọn địa chỉ")),
      );

      return;
    }

    try {
      final checkoutPaymentMethod = effectivePaymentMethod();

      /// 🔥 MOMO
      if (checkoutPaymentMethod == "WALLET") {
        final momoResponse = await MomoService.createPayment(total.toInt());

        if (!mounted) return;

        final result = await Navigator.push(
          context,

          MaterialPageRoute(
            builder: (_) => PaymentWebView(paymentUrl: momoResponse.payUrl),
          ),
        );

        /// 🔥 PAYMENT SUCCESS
        if (result == true) {
          await orderService.checkout({
            "addressId": selectedAddressId,

            "phone": "0123456789",

            "paymentMethod": "MOMO",

            "voucherCode": widget.voucherCode,

            "items": mapCart(),
          });

          await CartService().clearCart();

          if (!mounted) return;

          widget.cart.clear();

          Navigator.pop(context);

          showAppSnackBar(
            context,
            const SnackBar(content: Text("Thanh toán thành công ✅")),
          );
        }

        return;
      }

      /// 🔥 COD
      await orderService.checkout({
        "addressId": selectedAddressId,

        "phone": "0123456789",

        "paymentMethod": checkoutPaymentMethod,

        "voucherCode": widget.voucherCode,

        "items": mapCart(),
      });

      if (!mounted) return;

      await CartService().clearCart();

      if (!mounted) return;

      widget.cart.clear();

      Navigator.pop(context);

      showAppSnackBar(
        context,
        const SnackBar(content: Text("Đặt hàng thành công ✅")),
      );
    } catch (e) {
      if (!mounted) return;

      showAppSnackBar(context, SnackBar(content: Text("Checkout lỗi: $e")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff6f7f8),

      appBar: AppBar(title: const Text("Checkout"), centerTitle: true),

      bottomNavigationBar: CheckoutBottomBar(
        total: total,
        onCheckout: selectedAddressId == null ? null : handleCheckout,
      ),

      /// 🔥 KHÔNG dùng ListView
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            AddressSection(onSelect: calculateShipping),

            const SizedBox(height: 12),

            ShippingMethodSection(
              baseFee: baseShipping,
              onChanged: (fee) {
                /// 🔥 delay tránh crash
                Future.delayed(Duration.zero, () {
                  if (!mounted) return;

                  setState(() {
                    shippingFee = fee;
                  });
                });
              },
            ),

            const SizedBox(height: 12),

            PaymentMethodSection(
              onChanged: (method) {
                paymentMethod = method;
              },
            ),

            const SizedBox(height: 12),

            OrderSummarySection(
              subtotal: widget.totalPrice,
              shipping: shippingFee,
              total: total,
            ),

            const SizedBox(height: 100),
          ],
        ),
      ),
    );
  }
}
