package com.example.ecommerce.services;

import java.util.List;

import com.example.ecommerce.dto.CategoryResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ecommerce.model.Category;
import com.example.ecommerce.repository.CategoryRepository;

@Service
public class CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    public List<CategoryResponse> getCategoryTree() {
        List<Category> parents = categoryRepository.findByParentIsNull();

        return parents.stream()
                .map(CategoryResponse::new)
                .toList();
    }

    public Category createCategory(String name, Long parentId) {

        Category category = new Category();
        category.setName(name);

        if (parentId != null) {
            Category parent = categoryRepository.findById(parentId)
                    .orElseThrow(() -> new RuntimeException("Parent not found"));
            category.setParent(parent);
        }

        return categoryRepository.save(category);
    }
}