package com.example.ecommerce.controller;

import com.example.ecommerce.dto.ProductDetailResponse;
import com.example.ecommerce.dto.VariantResponse;
import com.example.ecommerce.model.Category;
import com.example.ecommerce.model.Product;
import com.example.ecommerce.model.ProductVariant;
import com.example.ecommerce.repository.CategoryRepository;
import com.example.ecommerce.repository.ProductImageRepository;
import com.example.ecommerce.repository.ProductRepository;
import com.example.ecommerce.repository.ProductVariantRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = "*")
public class ProductController {

    @Autowired
    private ProductRepository productRepo;

    @Autowired
    private ProductVariantRepository variantRepo;

    @Autowired
    private ProductImageRepository imageRepo;

    @Autowired
    private CategoryRepository categoryRepo;

    // =========================
    // GET ALL / FILTER / SEARCH
    // =========================
    @GetMapping
    public List<ProductDetailResponse> getAll(
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) String keyword) {

        List<Product> products;

        if (categoryId != null) {

            Category category = categoryRepo.findById(categoryId)
                    .orElseThrow(() -> new RuntimeException("Category not found"));

            if (category.getParent() == null) {

                List<Long> subIds = categoryRepo.findByParentId(categoryId)
                        .stream()
                        .map(Category::getId)
                        .collect(Collectors.toList());

                products = productRepo.findByCategoryIdIn(subIds);

            } else {
                products = productRepo.findByCategoryId(categoryId);
            }

        } else {
            products = productRepo.findAll();
        }

        // 🔍 SEARCH
        if (keyword != null && !keyword.isEmpty()) {
            String lower = keyword.toLowerCase();

            products = products.stream()
                    .filter(p -> p.getName().toLowerCase().contains(lower))
                    .collect(Collectors.toList());
        }

        return products.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    // =========================
    // GET DETAIL
    // =========================
    @GetMapping("/{id}")
    public ProductDetailResponse getDetail(@PathVariable Long id) {

        Product product = productRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        return mapToResponse(product);
    }

    // =========================
    // CREATE PRODUCT
    // =========================
    @PostMapping
    public Product create(@RequestBody Product product) {

        if (product.getCategory() == null) {
            throw new RuntimeException("Category is required");
        }

        Category category = categoryRepo.findById(product.getCategory().getId())
                .orElseThrow(() -> new RuntimeException("Category not found"));

        // ❌ không cho chọn category cha
        if (category.getParent() == null) {
            throw new RuntimeException("Phải chọn subcategory");
        }

        product.setCategory(category);

        return productRepo.save(product);
    }

    // =========================
    // GET VARIANTS
    // =========================
    @GetMapping("/{id}/variants")
    public List<ProductVariant> getVariants(@PathVariable Long id) {
        return variantRepo.findByProductId(id);
    }

    // =========================
    // ADD VARIANT
    // =========================
    @PostMapping("/variant")
    public ProductVariant addVariant(@RequestBody ProductVariant v) {
        return variantRepo.save(v);
    }

    // =========================
    // MAP RESPONSE (QUAN TRỌNG)
    // =========================
    private ProductDetailResponse mapToResponse(Product p) {

        List<ProductVariant> variants = variantRepo.findByProductId(p.getId());

        // 🖼 IMAGE (lấy từ variant đầu)
        String image = "";
        if (!variants.isEmpty()) {
            List<String> images = imageRepo.findByVariantId(variants.get(0).getId())
                    .stream()
                    .map(img -> img.getImageUrl())
                    .collect(Collectors.toList());

            if (!images.isEmpty()) {
                image = images.get(0);
            }
        }

        // 💰 PRICE RANGE (SAFE)
        double minPrice = variants.stream()
                .mapToDouble(ProductVariant::getPrice)
                .min()
                .orElse(0);

        double maxPrice = variants.stream()
                .mapToDouble(ProductVariant::getPrice)
                .max()
                .orElse(0);

     List<VariantResponse> variantResponses = variants.stream().map(v -> {

    VariantResponse vr = new VariantResponse();
    vr.setId(v.getId());
    vr.setSize(v.getSize());
    vr.setColor(v.getColor());
    vr.setPrice(v.getPrice());

    // 🔥 SAFE
    Double oldPrice = v.getOldPrice();
    vr.setOldPrice(oldPrice);

    // ❗ KHÔNG BAO GIỜ làm:
    // if (v.getOldPrice() > ...)

    if (oldPrice != null && oldPrice > v.getPrice()) {
        // nếu cần logic discount
    }

    vr.setStock(v.getStock());

    List<String> images = imageRepo.findByVariantId(v.getId())
            .stream()
            .map(img -> img.getImageUrl())
            .collect(Collectors.toList());

    vr.setImages(images);

    return vr;

}).collect(Collectors.toList());

        // 📦 RESPONSE
        ProductDetailResponse res = new ProductDetailResponse();
        res.setId(p.getId());
        res.setName(p.getName());
        res.setDescription(p.getDescription());
        res.setMinPrice(minPrice);
        res.setMaxPrice(maxPrice);
        res.setImage(image);
        res.setVariants(variantResponses);

        return res;
    }
}