package com.example.ecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.ecommerce.dto.*;
import com.example.ecommerce.model.Category;

import java.util.*;
import java.util.stream.Collectors;

import com.example.ecommerce.services.CategoryService;
import com.example.ecommerce.repository.CategoryRepository;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {
    @Autowired
    private CategoryRepository categoryRepository;
    @Autowired
    private CategoryService categoryService;

    @GetMapping
    public List<CategoryResponse> getCategories() {
        List<Category> parents = categoryRepository.findByParentIsNull();

        return parents.stream()
                .map(CategoryResponse::new)
                .collect(Collectors.toList());
    }

    @PostMapping
    public Category createCategory(@RequestBody CategoryRequest request) {
        return categoryService.createCategory(
                request.getName(),
                request.getParentId());
    }
}