package com.example.ecommerce.dto;

import java.util.List;

import com.example.ecommerce.model.Category;

import lombok.Data;

@Data
public class CategoryResponse {

    private Long id;
    private String name;
    private String banner; // 🔥 thêm
    private List<CategoryResponse> children;

    public CategoryResponse(Category category) {
        this.id = category.getId();
        this.name = category.getName();
        this.banner = category.getBanner(); // 🔥 lấy từ DB

        this.children = category.getChildren() != null
                ? category.getChildren()
                    .stream()
                    .map(CategoryResponse::new)
                    .toList()
                : List.of();
    }
}